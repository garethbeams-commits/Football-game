package uk.co.guessthefootballer.beta;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + APP_HOST + "/assets/www/index.html";
    private static final int PICK_BACKUP = 211;
    private static final int WRITE_BACKUP = 212;
    private WebView gameView;
    private android.webkit.ValueCallback<Uri[]> uploadCallback;
    private String backupContent;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        gameView = new WebView(this);
        gameView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(gameView);
        final WebSettings settings = gameView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Needed only for Android's document picker.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);

        gameView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return loader.shouldInterceptRequest(req.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme())
                        && APP_HOST.equalsIgnoreCase(uri.getHost())) return false;
                // The game stays inside the APK. Any external link leaves the WebView.
                if (!request.isForMainFrame()) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Cannot open this link", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        gameView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView,
                    android.webkit.ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = filePathCallback;
                try {
                    Intent picker = fileChooserParams.createIntent();
                    picker.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(picker, PICK_BACKUP);
                    return true;
                } catch (ActivityNotFoundException e) {
                    uploadCallback = null;
                    filePathCallback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No file picker installed", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        // Secure origin-scoped JavaScript messages, available only to bundled game pages.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(gameView, "GuessFootballerNative",
                    Collections.singleton("https://" + APP_HOST),
                    (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                        if (!isMainFrame || sourceOrigin == null || !APP_HOST.equals(sourceOrigin.getHost())) return;
                        try {
                            JSONObject payload = new JSONObject(message.getData());
                            String action = payload.optString("action");
                            if ("saveBackup".equals(action)) {
                                final String contents = payload.optString("contents");
                                final String filename = payload.optString("filename", "Footballer-Backup.json");
                                if (contents.length() > 2_000_000) return;
                                runOnUiThread(() -> chooseBackupDestination(contents, filename));
                            } else if ("shareText".equals(action)) {
                                String text = payload.optString("text");
                                if (text.length() > 10000) return;
                                runOnUiThread(() -> shareScore(text));
                            }
                        } catch (Exception ignored) {
                            // Malformed messages never break the game.
                        }
                    });
        }

        gameView.loadUrl(START_URL);
    }

    private void shareScore(String message) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(Intent.createChooser(send, "Share your score"));
    }

    private void chooseBackupDestination(String contents, String filename) {
        backupContent = contents;
        Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        save.setType("application/json");
        save.addCategory(Intent.CATEGORY_OPENABLE);
        save.putExtra(Intent.EXTRA_TITLE, filename);
        try {
            startActivityForResult(save, WRITE_BACKUP);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No document saver installed", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_BACKUP && uploadCallback != null) {
            uploadCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            uploadCallback = null;
        } else if (requestCode == WRITE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && backupContent != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new IllegalStateException("No output stream");
                    output.write(backupContent.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Backup saved", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Backup could not be saved", Toast.LENGTH_LONG).show();
                }
            }
            backupContent = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (gameView.canGoBack()) {
            gameView.goBack();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Leave Guess the Footballer?")
                    .setMessage("Your saved scores and progress will remain on this phone.")
                    .setNegativeButton("Keep playing", null)
                    .setPositiveButton("Exit", (dialog, which) -> finish())
                    .show();
        }
    }

    @Override
    protected void onDestroy() {
        if (gameView != null) {
            gameView.destroy();
        }
        super.onDestroy();
    }
}
